---
name: b) New feature
about: Select this if you're adding a new feature to Keras.
labels: feature
assignees: fchollet
---

<!--
Please make sure you've read and understood our contributing guidelines;
https://github.com/keras-team/keras/blob/master/CONTRIBUTING.md
-->

This pull request closes #issue_number_here .

**- What I did**

**- How I did it**

**- How to verify it**
<!-- 
You need a good justification for not 
including tests for the new feature you added. 
-->


- [ ] I updated the docs.

This pull request adds a new feature to Keras. @fchollet, could you please take a look at it?
